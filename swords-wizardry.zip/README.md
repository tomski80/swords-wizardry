# Game System for Swords & Wizardry 
### Swords & Wizardry by Mythmere Games (mythmeregames.com)
![Foundry v11](https://img.shields.io/badge/foundry-v11-green)

### Compatible with the Swords & Wizardry rules

“Swords & Wizardry, S&W, and Mythmere Games are trademarks of Mythmere Games LLC,”

The author is not affiliated in any way with Mythmere Games LLC


